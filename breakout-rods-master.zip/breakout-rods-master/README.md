# breakout-rods
A javascript game which uses cuisenaire rods and breakout to teach math.

Just a place where I can practice using the javascript canvas. 
