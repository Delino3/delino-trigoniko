describe("ball", function() {
    it("can draw itself", function() {
        expect(1).toBe("code to write here");
    });
    it("can roll around the screen in a continious direction", function() {
        expect(1).toBe("code to write here");
    });
    it("bounces off objects and goes in the oposite direction", function() {
        expect(1).toBe("code to write here");
    });
});

describe("ball strike rod", function() {
    it("when it strikes a rod it attempts to merge it with an adjacent rod which is in the direction with which the ball is moving", function() {
        expect(1).toBe("code to write here");
    });
    it("it returns false if there is no appropriate rod to merge with", function() {
        expect(1).toBe("code to write here");
    });
    it("if the result of two rods merging into one rod is greater than 10 then the rod the ball is nearest too gets destroyed", function() {
        expect(1).toBe("code to write here");
    });
    it("removes rods from the grid before merging them, then places the new rod in the same position on the grid", function() {
        expect(1).toBe("code to write here");
    });
    it("removes the rod from the grid before destroying the rod", function() {
        expect(1).toBe("code to write here");
    });
});
